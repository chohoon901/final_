let data = [
    {
        mainName : "가전",
        subName : "에어컨",
        picture : "사진",
        name : "델루체 스탠드형 서큘레이터 DLF-C5110NK",
        stock : 10,
        price : 4500000,
        disc : 0.01,
        comment_count : 0
    }
]

let request = [
    {
        item_name : "델루체 스탠드형 서큘레이터 DLF-C5110NK",
        quantity : 2,
        total_amount : 45000
    }
]

export {data, request};
