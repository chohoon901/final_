const categorydata = [
    {
      id: 1,
      name: '스킨케어',
      items: ['item 1', 'item 2', 'item 3', 'item 4']
    },
    {
      id: 2,
      name: '가전',
      items: ['item 1', 'item 2', 'item 3', 'item 4']
    },
    {
      id: 3,
      name: '생필품',
      items: ['item 1', 'item 2', 'item 3', 'item 4']
    }
    
  ];

export default categorydata;