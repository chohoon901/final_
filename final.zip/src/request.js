let request = [
    {
        name : "델루체 스탠드형 서큘레이터 DLF-C5110NK",
        quantity : 2,
        price : 45000
    }
]